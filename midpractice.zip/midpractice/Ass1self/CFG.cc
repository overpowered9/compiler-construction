#include <iostream>
#include <string>
using namespace std;

class Token {
public:
    string data;  // Public so it can be accessed outside the class
    Token* next;  // Pointer to the next Token in the linked list
    Token* prev;  // Pointer to the previous Token in the linked list

    Token(string data) : data(data), next(nullptr), prev(nullptr) {}
};

class Rule {
private:
    Token* tokenHead;
    Token* tokenTail;

public:
    Rule* next;
    Rule* prev;

    Rule() : next(nullptr), prev(nullptr), tokenHead(nullptr), tokenTail(nullptr) {}

    void addToken(string tokenData) {
        Token* newToken = new Token(tokenData);
        if (!tokenHead) {
            tokenHead = newToken;
            tokenTail = newToken;
        } else {
            newToken->prev = tokenTail;
            tokenTail->next = newToken;
            tokenTail = newToken;
        }
    }

    ~Rule() {
        Token* currentToken = tokenHead;
        while (currentToken) {
            Token* temp = currentToken;
            currentToken = currentToken->next;
            delete temp;
        }
    }
};
class Prod
{
private:
    Rule* rulehead;
    Rule* ruletail;
public:
string nt;
Prod* next;
Prod* prev;
    Prod(string t):nt(t),next(nullptr),prev(nullptr),rulehead(nullptr),ruletail(nullptr)   { };
    ~Prod(
        
    ){
        Rule* newrule= rulehead ;
        while (newrule)
        {
            Rule* temp = newrule;
            newrule=newrule->next;
            delete temp;
        }
        
    };
};

class DoublyLinkedList
{
private:
    Prod* prodhead; 
    Prod* prodtail; 
public:

    DoublyLinkedList():prodhead(nullptr),prodtail(nullptr) {};
    ~DoublyLinkedList(){
        Prod* newprod= prodhead;
        while (newprod)
        {
            Prod* temp = newprod;
            newprod= newprod->next;
            delete temp;
        }
         
    };
};




int main() {
    // Test your Rule and Token classes here.
}
