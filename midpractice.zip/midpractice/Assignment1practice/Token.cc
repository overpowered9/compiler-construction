#include "Token.h"

Token::Token(const std::string t) : t(t), next(nullptr), prev(nullptr) {}
