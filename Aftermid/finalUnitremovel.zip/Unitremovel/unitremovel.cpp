#include "unitremoval.h"
#include <set>
#include <vector>
#include <iostream>
#include <map>
#include <queue>

std::set<std::string> findNullableNonTerminals(DoublyLinkedList& grammar) {
    std::set<std::string> nullable;
    
    std::cout << "\nStep 1: Finding nullable non-terminals\n";
    
    // First pass - find direct epsilon productions
    Prod* prod = grammar.gethead();
    while (prod) {
        Rule* rule = prod->rulehead;
        while (rule) {
            Token* token = rule->tokenHead;
            // Debug print
            std::cout << "Checking rule in " << prod->nt << ": ";
            Token* tempToken = token;
            while (tempToken) {
                std::cout << tempToken->data << " ";
                tempToken = tempToken->next;
            }
            std::cout << "\n";
            std::cout << "data check:\n"<<token->data << "\n";
            
            if (token->data == "E") {
                nullable.insert(prod->nt);
                std::cout << "Found nullable: " << prod->nt << "\n";
                break;
            }
            rule = rule->next;
        }
        prod = prod->next;
    }
    
    std::cout << "Nullable non-terminals: ";
    for (const auto& nt : nullable) {
        std::cout << nt << " ";
    }
    std::cout << "\n";
    
    return nullable;
}
Rule* createRule(const std::vector<std::string>& tokens) {
    Rule* newRule = new Rule();
    for (const auto& token : tokens) {
        newRule->addToken(token);
    }
    return newRule;
}
DoublyLinkedList* removeNullProduction(DoublyLinkedList& grammar) {
    DoublyLinkedList* newGrammar = new DoublyLinkedList();
    std::set<std::string> nullable = findNullableNonTerminals(grammar);
    
    std::cout << "\nStep 2: Processing productions\n";
    
    // Process each production
    Prod* currentProd = grammar.gethead();
    while (currentProd) {
        std::cout << "\nProcessing production: " << currentProd->nt << "\n";
        
        Prod* newProd = new Prod(currentProd->nt);
        bool addedRule = false;
        
        // Process each rule
        Rule* currentRule = currentProd->rulehead;
        while (currentRule) {
            Token* token = currentRule->tokenHead;
            
            // Debug print current rule
            std::cout << "Processing rule: ";
            Token* tempToken = token;
            while (tempToken) {
                std::cout << tempToken->data << " ";
                tempToken = tempToken->next;
            }
            std::cout << "\n";
            
            // Skip epsilon rules
            if (token && token->data == "E" && !token->next) {
                std::cout << "Skipping epsilon rule\n";
                currentRule = currentRule->next;
                continue;
            }
            
            // Handle non-epsilon rules
            if (token) {
                std::vector<std::string> tokens;
                while (token) {
                    tokens.push_back(token->data);
                    token = token->next;
                }
                
                // Add the original rule
                newProd->addRule(createRule(tokens));
                addedRule = true;
                std::cout << "Added original rule\n";
                
                // Generate combinations if rule contains nullable symbols
                for (size_t i = 0; i < tokens.size(); i++) {
                    if (nullable.find(tokens[i]) != nullable.end()) {
                        std::cout << "Found nullable symbol in rule: " << tokens[i] << "\n";
                        std::vector<std::string> newTokens = tokens;
                        newTokens.erase(newTokens.begin() + i);
                        if (!newTokens.empty()) {
                            newProd->addRule(createRule(newTokens));
                            addedRule = true;
                            std::cout << "Added new combination rule\n";
                        }
                    }
                }
            }
            currentRule = currentRule->next;
        }
        
        // Only add production if it has non-epsilon rules
        if (addedRule) {
            newGrammar->insertattail(newProd);
            std::cout << "Added production to new grammar\n";
        } else {
            delete newProd;
            std::cout << "Deleted empty production\n";
        }
        
        currentProd = currentProd->next;
    }
    
    return newGrammar;
}




// Helper function to get all rules from a non-terminal
std::vector<Rule*> getRules(Prod* prod) {
    std::vector<Rule*> rules;
    Rule* rule = prod->rulehead;
    while (rule) {
        rules.push_back(rule);
        rule = rule->next;
    }
    return rules;
}

bool isUnitProduction(Rule* rule) {
    // A unit production has exactly one token that is a non-terminal (uppercase)
    Token* token = rule->tokenHead;
    return (token && !token->next && isupper(token->data[0]));
}

DoublyLinkedList* removeUnitProduction(DoublyLinkedList& grammar) {
    DoublyLinkedList* result = new DoublyLinkedList();
    
    std::cout << "\nStep 1: Identifying unit productions and their transitions\n";
    
    // Step 1: Build unit production graph
    std::map<std::string, std::set<std::string>> unitGraph;
    Prod* prod = grammar.gethead();
    while (prod) {
        // Initialize with self-loop
        unitGraph[prod->nt].insert(prod->nt);
        Rule* rule = prod->rulehead;
        while (rule) {
            if (isUnitProduction(rule)) {
                std::cout << "Found unit production: " << prod->nt << " -> " 
                         << rule->tokenHead->data << "\n";
                unitGraph[prod->nt].insert(rule->tokenHead->data);
            }
            rule = rule->next;
        }
        prod = prod->next;
    }
    
    // Compute transitive closure
    bool changed;
    do {
        changed = false;
        for (const auto& pair : unitGraph) {
            std::set<std::string> newReachable = pair.second;
            for (const std::string& intermediate : pair.second) {
                for (const std::string& target : unitGraph[intermediate]) {
                    if (newReachable.insert(target).second) {
                        changed = true;
                    }
                }
            }
            unitGraph[pair.first] = newReachable;
        }
    } while (changed);
    
    std::cout << "\nStep 2: Creating new productions without unit productions\n";
    
    // Step 2: Create new productions
    prod = grammar.gethead();
    while (prod) {
        std::cout << "Processing " << prod->nt << "\n";
        Prod* newProd = new Prod(prod->nt);
        std::set<std::string> addedRules;  // To avoid duplicates
        
        // For each reachable non-terminal through unit productions
        for (const std::string& reachableNT : unitGraph[prod->nt]) {
            // Find the production for this non-terminal
            Prod* targetProd = grammar.gethead();
            while (targetProd && targetProd->nt != reachableNT) {
                targetProd = targetProd->next;
            }
            
            if (targetProd) {
                Rule* rule = targetProd->rulehead;
                while (rule) {
                    if (!isUnitProduction(rule)) {
                        // Convert rule to string for duplicate checking
                        std::string ruleStr;
                        Token* token = rule->tokenHead;
                        while (token) {
                            ruleStr += token->data;
                            if (token->next) ruleStr += " ";
                            token = token->next;
                        }
                        
                        if (addedRules.insert(ruleStr).second) {
                            std::cout << "Adding rule: " << prod->nt << " -> " << ruleStr << "\n";
                            Rule* newRule = new Rule();
                            token = rule->tokenHead;
                            while (token) {
                                newRule->addToken(token->data);
                                token = token->next;
                            }
                            newProd->addRule(newRule);
                        }
                    }
                    rule = rule->next;
                }
            }
        }
        
        if (newProd->rulehead) {
            result->insertattail(newProd);
        } else {
            delete newProd;
        }
        prod = prod->next;
    }
    
    return result;
}