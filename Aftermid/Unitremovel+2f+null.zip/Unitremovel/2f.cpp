#include <unordered_map>
#include <unordered_set>
#include <string>
#include <iostream>
#include <map>
#include <set>
#include <string>
#include "cfg.h"

#include <vector>

#include <unordered_map>
#include <unordered_set>
#include <string>
#include <iomanip>
class FirstFollowCalculator {
private:
    std::unordered_map<std::string, std::unordered_set<std::string>> firstSets;
    std::unordered_map<std::string, std::unordered_set<std::string>> followSets;
    DoublyLinkedList& grammar;

    bool isTerminal(const std::string& token) {
        return token[0] == '\'' || (token == "the" || token == "a");
    }

    std::string stripQuotes(const std::string& token) {
        if (token.size() >= 2 && token[0] == '\'' && token.back() == '\'') {
            return token.substr(1, token.size() - 2);
        }
        return token;
    }

    Prod* findProduction(const std::string& nt) {
        Prod* current = grammar.gethead();
        while (current) {
            if (current->nt == nt) return current;
            current = current->next;
        }
        return nullptr;
    }

    void computeFirstSet(const std::string& symbol) {
        if (firstSets.find(symbol) != firstSets.end()) return;

        firstSets[symbol] = std::unordered_set<std::string>();

        if (isTerminal(symbol)) {
            firstSets[symbol].insert(stripQuotes(symbol));
            return;
        }

        Prod* prod = findProduction(symbol);
        if (!prod) return;

        Rule* currentRule = prod->rulehead;
        while (currentRule) {
            Token* firstToken = currentRule->tokenHead;
            if (!firstToken) {
                currentRule = currentRule->next;
                continue;
            }

            computeFirstSet(firstToken->data);
            auto& firstSymbolSet = firstSets[firstToken->data];
            firstSets[symbol].insert(firstSymbolSet.begin(), firstSymbolSet.end());
            
            currentRule = currentRule->next;
        }
    }

    void computeFollowSet(const std::string& symbol) {
        if (followSets.find(symbol) != followSets.end()) return;

        followSets[symbol] = std::unordered_set<std::string>();
        
        // Add $ to FOLLOW(S) where S is the start symbol
        if (symbol == grammar.gethead()->nt) {
            followSets[symbol].insert("$");
        }

        // For each production
        Prod* currentProd = grammar.gethead();
        while (currentProd) {
            Rule* currentRule = currentProd->rulehead;
            
            // For each rule in the production
            while (currentRule) {
                Token* currentToken = currentRule->tokenHead;
                
                // For each token in the rule
                while (currentToken) {
                    // If we find our symbol
                    if (!isTerminal(currentToken->data) && currentToken->data == symbol) {
                        // Get the next token
                        Token* nextToken = currentToken->next;
                        
                        if (nextToken) {
                            // Add FIRST(next) to FOLLOW(symbol)
                            computeFirstSet(nextToken->data);
                            auto& firstNext = firstSets[nextToken->data];
                            followSets[symbol].insert(firstNext.begin(), firstNext.end());
                        } else {
                            // If there's no next token, add FOLLOW(lefthand) to FOLLOW(symbol)
                            // But only if lefthand != symbol (to prevent infinite recursion)
                            if (currentProd->nt != symbol) {
                                computeFollowSet(currentProd->nt);
                                auto& followLeft = followSets[currentProd->nt];
                                followSets[symbol].insert(followLeft.begin(), followLeft.end());
                            }
                        }
                    }
                    currentToken = currentToken->next;
                }
                currentRule = currentRule->next;
            }
            currentProd = currentProd->next;
        }
    }

public:
    FirstFollowCalculator(DoublyLinkedList& g) : grammar(g) {}

    void computeAllSets() {
        // First compute all FIRST sets
        Prod* current = grammar.gethead();
        while (current) {
            computeFirstSet(current->nt);
            current = current->next;
        }

        // Then compute all FOLLOW sets
        current = grammar.gethead();
        while (current) {
            computeFollowSet(current->nt);
            current = current->next;
        }
    }

    void printSets() {
        std::cout << "\nFIRST Sets:\n";
        Prod* current = grammar.gethead();
        while (current) {
            std::cout << "FIRST(" << current->nt << ") = { ";
            bool first = true;
            for (const auto& terminal : firstSets[current->nt]) {
                if (!first) std::cout << ", ";
                std::cout << terminal;
                first = false;
            }
            std::cout << " }\n";
            current = current->next;
        }

        std::cout << "\nFOLLOW Sets:\n";
        current = grammar.gethead();
        while (current) {
            std::cout << "FOLLOW(" << current->nt << ") = { ";
            bool first = true;
            for (const auto& terminal : followSets[current->nt]) {
                if (!first) std::cout << ", ";
                std::cout << terminal;
                first = false;
            }
            std::cout << " }\n";
            current = current->next;
        }
    }

    // Getters for use in predictive parsing
    const std::unordered_map<std::string, std::unordered_set<std::string>>& getFirstSets() const {
        return firstSets;
    }

    const std::unordered_map<std::string, std::unordered_set<std::string>>& getFollowSets() const {
        return followSets;
    }
};
class PredictiveParser {
private:
    std::map<std::pair<std::string, std::string>, Rule*> parsingTable;
    const std::unordered_map<std::string, std::unordered_set<std::string>>& firstSets;
    const std::unordered_map<std::string, std::unordered_set<std::string>>& followSets;
    DoublyLinkedList& grammar;

    bool isTerminal(const std::string& symbol) {
        return symbol[0] == '\'' || (symbol == "the" || symbol == "a");
    }

    void constructParsingTable() {
        Prod* currentProd = grammar.gethead();
        while (currentProd) {
            std::string nonTerminal = currentProd->nt;
            Rule* currentRule = currentProd->rulehead;
            
            while (currentRule) {
                Token* firstToken = currentRule->tokenHead;
                if (!firstToken) {
                    // Handle epsilon production
                    for (const auto& follow : followSets.at(nonTerminal)) {
                        parsingTable[{nonTerminal, follow}] = currentRule;
                    }
                } else {
                    std::string firstSymbol = firstToken->data;
                    if (isTerminal(firstSymbol)) {
                        // If first symbol is terminal, add to table
                        parsingTable[{nonTerminal, stripQuotes(firstSymbol)}] = currentRule;
                    } else {
                        // Add entries for all terminals in FIRST(firstSymbol)
                        for (const auto& terminal : firstSets.at(firstSymbol)) {
                            parsingTable[{nonTerminal, terminal}] = currentRule;
                        }
                    }
                }
                currentRule = currentRule->next;
            }
            currentProd = currentProd->next;
        }
    }

    std::string stripQuotes(const std::string& token) {
        if (token.size() >= 2 && token[0] == '\'' && token.back() == '\'') {
            return token.substr(1, token.size() - 2);
        }
        return token;
    }

public:
    PredictiveParser(DoublyLinkedList& g,
                    const std::unordered_map<std::string, std::unordered_set<std::string>>& first,
                    const std::unordered_map<std::string, std::unordered_set<std::string>>& follow)
        : grammar(g), firstSets(first), followSets(follow) {
        constructParsingTable();
    }

    bool parse(const std::vector<std::string>& input) {
        std::vector<std::string> stack = {"$", grammar.gethead()->nt};  // Start symbol
        size_t inputPos = 0;
        
        while (!stack.empty()) {
            std::string top = stack.back();
            std::string currentInput = inputPos < input.size() ? input[inputPos] : "$";
            
            if (top == "$" && currentInput == "$") {
                return true;  // Successful parse
            }
            
            if (isTerminal(top) || top == "$") {
                if (stripQuotes(top) == currentInput) {
                    stack.pop_back();
                    inputPos++;
                } else {
                    return false;  // Error
                }
            } else {
                auto entry = parsingTable.find({top, currentInput});
                if (entry == parsingTable.end()) {
                    return false;  // Error: no production found
                }
                
                stack.pop_back();
                // Add production symbols in reverse order
                Rule* rule = entry->second;
                std::vector<std::string> production;
                Token* token = rule->tokenHead;
                while (token) {
                    production.push_back(token->data);
                    token = token->next;
                }
                for (auto it = production.rbegin(); it != production.rend(); ++it) {
                    stack.push_back(*it);
                }
            }
        }
        return false;
    }

    void printParsingTable() {
        std::cout << "\nPredictive Parsing Table:\n";
        std::map<std::string, std::set<std::string>> terminalColumns;
        std::set<std::string> nonTerminals;
        
        // Collect all terminals and non-terminals
        for (const auto& entry : parsingTable) {
            nonTerminals.insert(entry.first.first);
            terminalColumns[entry.first.second];
        }

        // Print header
        std::cout << "Non-terminal | ";
        for (const auto& terminal : terminalColumns) {
            std::cout << std::setw(15) << terminal.first << " | ";
        }
        std::cout << "\n" << std::string(nonTerminals.size() * 20, '-') << "\n";

        // Print table contents
        for (const auto& nt : nonTerminals) {
            std::cout << std::setw(11) << nt << " | ";
            for (const auto& terminal : terminalColumns) {
                auto entry = parsingTable.find({nt, terminal.first});
                if (entry != parsingTable.end()) {
                    std::string production;
                    Token* token = entry->second->tokenHead;
                    while (token) {
                        production += token->data + " ";
                        token = token->next;
                    }
                    std::cout << std::setw(15) << production << " | ";
                } else {
                    std::cout << std::setw(15) << "error" << " | ";
                }
            }
            std::cout << "\n";
        }
    }
};
int main() {
    DoublyLinkedList prodList;

    // S -> NP VP
    Prod* prodS = new Prod("S");
    Rule* ruleS = new Rule();
    ruleS->addToken("NP");
    ruleS->addToken("VP");
    prodS->addRule(ruleS);
    prodList.insertattail(prodS);

    // NP -> DET N | NP PP
    Prod* prodNP = new Prod("NP");
    Rule* ruleNP1 = new Rule();
    ruleNP1->addToken("DET");
    ruleNP1->addToken("N");
    Rule* ruleNP2 = new Rule();
    ruleNP2->addToken("NP");
    ruleNP2->addToken("PP");
    prodNP->addRule(ruleNP1);
    prodNP->addRule(ruleNP2);
    prodList.insertattail(prodNP);

    // VP -> V NP | VP PP | V
    Prod* prodVP = new Prod("VP");
    Rule* ruleVP1 = new Rule();
    ruleVP1->addToken("V");
    ruleVP1->addToken("NP");
    Rule* ruleVP2 = new Rule();
    ruleVP2->addToken("VP");
    ruleVP2->addToken("PP");
    Rule* ruleVP3 = new Rule();
    ruleVP3->addToken("V");
    prodVP->addRule(ruleVP1);
    prodVP->addRule(ruleVP2);
    prodVP->addRule(ruleVP3);
    prodList.insertattail(prodVP);

    // PP -> P NP
    Prod* prodPP = new Prod("PP");
    Rule* rulePP = new Rule();
    rulePP->addToken("P");
    rulePP->addToken("NP");
    prodPP->addRule(rulePP);
    prodList.insertattail(prodPP);

    // DET -> 'the' | 'a'
    Prod* prodDET = new Prod("DET");
    Rule* ruleDET1 = new Rule();
    ruleDET1->addToken("the");
    Rule* ruleDET2 = new Rule();
    ruleDET2->addToken("a");
    prodDET->addRule(ruleDET1);
    prodDET->addRule(ruleDET2);
    prodList.insertattail(prodDET);

    // N -> 'cat' | 'dog' | 'man' | 'woman'
    Prod* prodN = new Prod("N");
    Rule* ruleN1 = new Rule();
    ruleN1->addToken("'cat'");
    Rule* ruleN2 = new Rule();
    ruleN2->addToken("'dog'");
    Rule* ruleN3 = new Rule();
    ruleN3->addToken("'man'");
    Rule* ruleN4 = new Rule();
    ruleN4->addToken("'woman'");
    prodN->addRule(ruleN1);
    prodN->addRule(ruleN2);
    prodN->addRule(ruleN3);
    prodN->addRule(ruleN4);
    prodList.insertattail(prodN);

    // V -> 'chased' | 'caught'
    Prod* prodV = new Prod("V");
    Rule* ruleV1 = new Rule();
    ruleV1->addToken("'chased'");
    Rule* ruleV2 = new Rule();
    ruleV2->addToken("'caught'");
    prodV->addRule(ruleV1);
    prodV->addRule(ruleV2);
    prodList.insertattail(prodV);

    // P -> 'in' | 'on' | 'with'
    Prod* prodP = new Prod("P");
    Rule* ruleP1 = new Rule();
    ruleP1->addToken("'in'");
    Rule* ruleP2 = new Rule();
    ruleP2->addToken("'on'");
    Rule* ruleP3 = new Rule();
    ruleP3->addToken("'with'");
    prodP->addRule(ruleP1);
    prodP->addRule(ruleP2);
    prodP->addRule(ruleP3);
    prodList.insertattail(prodP);

    // Print the original grammar
    std::cout << "Original Grammar:\n";
    Prod* currentProd = prodList.gethead();
    while (currentProd) {
        std::cout << currentProd->nt << " -> ";
        Rule* currentRule = currentProd->rulehead;
        while (currentRule) {
            Token* currentToken = currentRule->tokenHead;
            while (currentToken) {
                std::cout << currentToken->data;
                if (currentToken->next) std::cout << " ";
                currentToken = currentToken->next;
            }
            currentRule = currentRule->next;
            if (currentRule) std::cout << " | ";
        }
        std::cout << std::endl;
        currentProd = currentProd->next;
    }

    FirstFollowCalculator calculator(prodList);
    calculator.computeAllSets();
    calculator.printSets();
    // Create and use the predictive parser
    PredictiveParser parser(prodList, calculator.getFirstSets(), calculator.getFollowSets());

// Test some inputs
    std::vector<std::string> input1 = {"the", "cat", "caught", "the", "dog"};
    std::cout << "Input 1 is " << (parser.parse(input1) ? "valid" : "invalid") << "\n";

    return 0;
}