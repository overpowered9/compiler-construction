#include "unitremoval.h"
#include <set>
#include <vector>
#include <iostream>
#include <map>
#include <queue>

std::set<std::string> findNullableNonTerminals(DoublyLinkedList& grammar) {
    std::set<std::string> nullable;
    
    std::cout << "\nStep 1: Finding nullable non-terminals\n";
    
    // First pass - find direct epsilon productions
    Prod* prod = grammar.gethead();
    while (prod) {
        Rule* rule = prod->rulehead;
        while (rule) {
            Token* token = rule->tokenHead;
            // Debug print
            std::cout << "Checking rule in " << prod->nt << ": ";
            Token* tempToken = token;
            while (tempToken) {
                std::cout << tempToken->data << " ";
                tempToken = tempToken->next;
            }
            std::cout << "\n";
            std::cout << "data check:\n"<<token->data << "\n";
            
            if (token->data == "E") {
                nullable.insert(prod->nt);
                std::cout << "Found nullable: " << prod->nt << "\n";
                break;
            }
            rule = rule->next;
        }
        prod = prod->next;
    }
    
    std::cout << "Nullable non-terminals: ";
    for (const auto& nt : nullable) {
        std::cout << nt << " ";
    }
    std::cout << "\n";
    
    return nullable;
}
Rule* createRule(const std::vector<std::string>& tokens) {
    Rule* newRule = new Rule();
    for (const auto& token : tokens) {
        newRule->addToken(token);
    }
    return newRule;
}
DoublyLinkedList* removeNullProduction(DoublyLinkedList& grammar) {
    DoublyLinkedList* newGrammar = new DoublyLinkedList();
    std::set<std::string> nullable = findNullableNonTerminals(grammar);
    
    std::cout << "\nStep 2: Processing productions\n";
    
    // Process each production
    Prod* currentProd = grammar.gethead();
    while (currentProd) {
        std::cout << "\nProcessing production: " << currentProd->nt << "\n";
        
        Prod* newProd = new Prod(currentProd->nt);
        bool addedRule = false;
        
        // Process each rule
        Rule* currentRule = currentProd->rulehead;
        while (currentRule) {
            Token* token = currentRule->tokenHead;
            
            // Debug print current rule
            std::cout << "Processing rule: ";
            Token* tempToken = token;
            while (tempToken) {
                std::cout << tempToken->data << " ";
                tempToken = tempToken->next;
            }
            std::cout << "\n";
            
            // Skip epsilon rules
            if (token && token->data == "E" && !token->next) {
                std::cout << "Skipping epsilon rule\n";
                currentRule = currentRule->next;
                continue;
            }
            
            // Handle non-epsilon rules
            if (token) {
                std::vector<std::string> tokens;
                while (token) {
                    tokens.push_back(token->data);
                    token = token->next;
                }
                
                // Add the original rule
                newProd->addRule(createRule(tokens));
                addedRule = true;
                std::cout << "Added original rule\n";
                
                // Generate combinations if rule contains nullable symbols
                for (size_t i = 0; i < tokens.size(); i++) {
                    if (nullable.find(tokens[i]) != nullable.end()) {
                        std::cout << "Found nullable symbol in rule: " << tokens[i] << "\n";
                        std::vector<std::string> newTokens = tokens;
                        newTokens.erase(newTokens.begin() + i);
                        if (!newTokens.empty()) {
                            newProd->addRule(createRule(newTokens));
                            addedRule = true;
                            std::cout << "Added new combination rule\n";
                        }
                    }
                }
            }
            currentRule = currentRule->next;
        }
        
        // Only add production if it has non-epsilon rules
        if (addedRule) {
            newGrammar->insertattail(newProd);
            std::cout << "Added production to new grammar\n";
        } else {
            delete newProd;
            std::cout << "Deleted empty production\n";
        }
        
        currentProd = currentProd->next;
    }
    
    return newGrammar;
}



// Helper function to check if a rule is a unit production
bool isUnitProduction(Rule* rule) {
    return (rule->tokenHead && !rule->tokenHead->next && 
            isupper(rule->tokenHead->data[0]));  // Assumes non-terminals start with uppercase
}

// Helper function to get all rules from a non-terminal
std::vector<Rule*> getRules(Prod* prod) {
    std::vector<Rule*> rules;
    Rule* rule = prod->rulehead;
    while (rule) {
        rules.push_back(rule);
        rule = rule->next;
    }
    return rules;
}

DoublyLinkedList* removeUnitProduction(DoublyLinkedList& grammar) {
    DoublyLinkedList* result = new DoublyLinkedList();
    std::map<std::string, std::set<std::string>> unitTransitions;
    
    // Step 1: Find all unit transitions (direct and indirect)
    Prod* currentProd = grammar.gethead();
    while (currentProd) {
        std::queue<std::string> queue;
        std::set<std::string>& reachable = unitTransitions[currentProd->nt];
        reachable.insert(currentProd->nt);  // Add self-transition
        
        // Find direct unit productions
        Rule* currentRule = currentProd->rulehead;
        while (currentRule) {
            if (isUnitProduction(currentRule)) {
                queue.push(currentRule->tokenHead->data);
                reachable.insert(currentRule->tokenHead->data);
            }
            currentRule = currentRule->next;
        }
        
        // Find indirect unit productions
        while (!queue.empty()) {
            std::string current = queue.front();
            queue.pop();
            
            // Find production for current non-terminal
            Prod* targetProd = grammar.gethead();
            while (targetProd && targetProd->nt != current) {
                targetProd = targetProd->next;
            }
            
            if (targetProd) {
                Rule* targetRule = targetProd->rulehead;
                while (targetRule) {
                    if (isUnitProduction(targetRule)) {
                        std::string newNT = targetRule->tokenHead->data;
                        if (reachable.find(newNT) == reachable.end()) {
                            reachable.insert(newNT);
                            queue.push(newNT);
                        }
                    }
                    targetRule = targetRule->next;
                }
            }
        }
        currentProd = currentProd->next;
    }
    
    // Step 2: Create new grammar without unit productions
    currentProd = grammar.gethead();
    while (currentProd) {
        Prod* newProd = new Prod(currentProd->nt);
        std::set<std::string> addedRules;  // To avoid duplicates
        
        // For each reachable non-terminal via unit productions
        for (const std::string& reachableNT : unitTransitions[currentProd->nt]) {
            // Find production for reachable non-terminal
            Prod* targetProd = grammar.gethead();
            while (targetProd && targetProd->nt != reachableNT) {
                targetProd = targetProd->next;
            }
            
            if (targetProd) {
                Rule* targetRule = targetProd->rulehead;
                while (targetRule) {
                    if (!isUnitProduction(targetRule)) {
                        // Convert rule to string for duplicate checking
                        std::string ruleStr;
                        Token* token = targetRule->tokenHead;
                        while (token) {
                            ruleStr += token->data + " ";
                            token = token->next;
                        }
                        
                        // Add rule if not already added
                        if (addedRules.find(ruleStr) == addedRules.end()) {
                            Rule* newRule = new Rule();
                            token = targetRule->tokenHead;
                            while (token) {
                                newRule->addToken(token->data);
                                token = token->next;
                            }
                            newProd->addRule(newRule);
                            addedRules.insert(ruleStr);
                        }
                    }
                    targetRule = targetRule->next;
                }
            }
        }
        
        // Only add production if it has rules
        if (newProd->rulehead) {
            result->insertattail(newProd);
        } else {
            delete newProd;
        }
        
        currentProd = currentProd->next;
    }
    
    return result;
}