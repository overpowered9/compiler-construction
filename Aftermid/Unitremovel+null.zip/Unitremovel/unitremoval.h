#ifndef UNITREMOVAL_H
#define UNITREMOVAL_H

#include "cfg.h"
#include <string>
#include <set>
#include <vector>

// Function to identify all nullable non-terminals in the grammar
std::set<std::string> findNullableNonTerminals(DoublyLinkedList& grammar);
Rule* createRule(const std::vector<std::string>& tokens);
// Helper function to generate all possible combinations of tokens
// when some tokens can be nullable
void generateCombinations(Token* token, 
                         const std::set<std::string>& nullable,
                         std::vector<std::vector<std::string>>& results,
                         std::vector<std::string>& current);

// Main function to remove null productions from the grammar
// Returns a new grammar without null productions
DoublyLinkedList* removeNullProduction(DoublyLinkedList& grammar);
bool isUnitProduction(Rule* rule);
std::vector<Rule*> getRules(Prod* prod);
DoublyLinkedList* removeUnitProduction(DoublyLinkedList& grammar);

#endif 